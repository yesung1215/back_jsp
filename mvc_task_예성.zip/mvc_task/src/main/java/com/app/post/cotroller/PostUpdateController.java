package com.app.post.cotroller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.Action;
import com.app.Result;
import com.app.dao.PostDAO;
import com.app.exception.PostNotFoundException;
import com.app.vo.PostVO;

public class PostUpdateController implements Action {

	@Override
	public Result execute(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		Result result = new Result();
		PostDAO postDAO = new PostDAO();
		Long id = Long.parseLong(req.getParameter("id"));
		
		try {
			PostVO foundPost = postDAO.select(id).orElseThrow(PostNotFoundException::new);
			req.setAttribute("post", foundPost);
		} catch (PostNotFoundException e) {
			result.setPath("/erorr.jsp");
			req.setAttribute("message", "게시글을 찾을 수 없습니다.");
			System.out.println("PostUpdateController Product Not Found Error");
		}
		result.setPath("/update.jsp");
		return result;
	}

}
